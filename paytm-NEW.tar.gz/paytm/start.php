<?php

	$error=null;
include'welcome.php';
?><!doctype html>
<html>
<head>
<style>
.container
{
	background-color:#F3EFEF;
	margin-top: 3%;
	margin-right: 1%;
	margin-left: 1%;
	margin-bottom: 3%;
}
</style>
<meta charset="utf-8" name="viewport" content="width=device.width,initial-scale=1.0">
<title>paytm</title>
</head>
<body>
<div class="container">
<a href="showselldata.php?type=BABY KIDS"><img src="homepicures/kids/6.jpg" width="58%" height="372"></a>
<a href="showselldata.php?type=MENS FASHION"><img src="homepicures/men/1.jpg" width="41%" height="379"></a>
<a href="showselldata.php?type=MOBILE ACCESSORIES"><img src="homepicures/mobile/6.jpg" width="48%" height="314"></a>
<a href="showselldata.php?type=WOMENS FASHION"><img src="homepicures/women/1.jpg" width="50%" height="314"></a>
<a href="showselldata.php?type=WOMENS FASHION"><img src="homepicures/women/4.jpg" width="100%" height="374"></a>
<a href="showselldata.php?type=MOBILE ACCESSORIES"><img src="homepicures/mobile/9.jpg" width="100%" height="374"></a>
<a href="showselldata.php?type=MENS FASHION"><img src="homepicures/men/6.jpg" width="100%" height="374"></a>
<a href="showselldata.php?type=BABY KIDS"><img src="homepicures/kids/4.jpg" width="100%" height="374"></a>
</div>
</body>
</html>
<?php
include'footer.php';
?>
