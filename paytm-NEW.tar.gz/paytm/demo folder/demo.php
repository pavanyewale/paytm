if($i==1)
{
$sql='select * from bank where atmno='.$_POST['atmno'];

$result=mysql_query($sql) or die("cannot execute query".mysql_error());
   if($result)
     {
       $data=mysql_fetch_row($result);
	   
          if($data[11]==$_POST["atmpassword"] && $data[7]==$_POST["cvvno"] && $data[8]==$_POST["month"] && $data[9]==$_POST["year"])
            { 
              if($data[6]>$_POST["amount"])
                {
	                $sql='update bank set amount =amount-'.$_POST["amount"].' where atmno='.$_POST["atmno"];
                    $s=mysql_query($sql) or die("cannot update bank ".mysql_error());	
	                  if($s)
	                     {
		                    $sql='update paytm set amount=amount+'.$_POST['amount'].' where userid='.$id;
		                      $s=mysql_query($sql) or die('cannot update paytm'.mysql_error());
		                         if($s)
		                             {
			                          header("location:addmoney.php?sucess=1");
			                          }
			                      else{
				                       $error='Trasaction failed';
				                       } 
		
		
		                  }
		                   else{
			                    $error='Transation failed';
			                    }
	
				}else
                   {
                    $error='No enough balance in your bank account';
                    }
          }
          else{
	         $error='1.......Please Insert a correct Information';
                }
     }
	 else
      {
	$error='2.............Please Insert a correct Information';
	  }

}else
{
	$error="Something missed to enter....!";
}