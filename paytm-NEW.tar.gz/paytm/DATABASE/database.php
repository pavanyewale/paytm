
<?php

////****************************database design***************************
$conn= mysqli_connect("localhost",'root','') or die("cannot connect to localhost");
mysqli_query($conn,'DROP DATABASE paytm');
mysqli_query($conn,'CREATE DATABASE paytm');
mysqli_select_db($conn,"paytm") or die("cannot select database");

$sql="create table paytm(userid int auto_increment primary key,name varchar(30),email varchar(50),password varchar(8) not null,gender varchar(8),mobileno int(10),amount int(10))";
mysqli_query($conn,$sql);
$sql="Create table userimage(userid int references paytm(userid),up_date date,img LONGBLOB,iname varchar(20),likes int)";
mysqli_query($conn,$sql) ;

$sql="create table bank(fname varchar(20) not null,lname varchar(20) not null,email varchar(50)  not null,password varchar(8) not null,gender varchar(8),debitno int,accountno int auto_increment primary key,amount int,cvvno int(3),exmonth int(2),ex_year int(4),atmno bigint(16),atm_password int(4))";
mysqli_query($conn,$sql);

$sql='create table sell(id int auto_increment not null primary key,name varchar(50),price int ,photopath varchar(40),discount int ,description text,contity int,category varchar(50))';
mysqli_query($conn,$sql);

$sql='create table passbook(userid int ,ttype text,ttime varchar(15),tdate date,tamount float)';
mysqli_query($conn,$sql) or die('cannot create table passbook'.mysqli_error($conn));
echo "DATABASE CREATED SUCCESSFULLY.....:)";
?>