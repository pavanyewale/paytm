<?php

	$error=null;
include 'welcome.php';
?><!doctype html>
<html>
<head>
<style>
.help
{
	background-color:#AAA9A9;
	clear:both;
	width:100%;	
	}
</style>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>

<div class='help'>We are helping you here....!
<br>If you are not created account for paytm yet go on create account link which is in right corner above the page. Fill the all information and click on next. then you will get an email on email which is enterd in the form ,enter the code in the box and click confirm and your account is create successfully. 
<br>For log in to paytm just click on login link and enter email and password which you entered at the time of account creation .and click on login .
<br>
for sell on paytm click on nevigation icon select the sell on paytm and enter all information and click add before you add an item to paytm for sell , you must have an account and loged in it<br>
For recharge click on recharge fill info and you will recharge throught it.
<br>
For accept payment you can accept it with your mobile number . you can accept your payment with mobile number only throught paytm.
</div>
</body>
</html>

<?php
include'footer.php';
?>
