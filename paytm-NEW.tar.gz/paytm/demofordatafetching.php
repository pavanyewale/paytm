<?php

	$error=null;
include'welcome.php';
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
$result=mysqli_query($conn ,'select * from bank') or die('Cannot run qry'.mysqli_error($conn));
while($row=mysqli_fetch_array($result))
{
	echo $row['atmpassword'].'<br>';
	}


?>
</body>
</html>
