-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 06, 2017 at 08:46 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `paytm`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(8) NOT NULL,
  `gender` varchar(8) default NULL,
  `accountno` int(11) NOT NULL auto_increment,
  `amount` int(11) default NULL,
  `cvvno` int(3) default NULL,
  `exmonth` int(2) default NULL,
  `ex_year` int(4) default NULL,
  `atmno` bigint(16) default NULL,
  `atmpassword` int(4) NOT NULL,
  PRIMARY KEY  (`accountno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`fname`, `lname`, `email`, `password`, `gender`, `accountno`, `amount`, `cvvno`, `exmonth`, `ex_year`, `atmno`, `atmpassword`) VALUES
('rohit', 'korhale', 'rk@gmail.com', '12345678', 'male', 4, 9830, 499, 2, 2037, 9203216593693847, 6528);

-- --------------------------------------------------------

--
-- Table structure for table `passbook`
--

CREATE TABLE `passbook` (
  `userid` int(11) default NULL,
  `ttype` text,
  `tdate` varchar(20) default NULL,
  `tamount` float default '0',
  `tfor` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `passbook`
--

INSERT INTO `passbook` (`userid`, `ttype`, `tdate`, `tamount`, `tfor`) VALUES
(2, 'bank transfer', '22Feb2017', 50, '4'),
(2, 'added to wallet', '22Feb2017', 100, '92032165936'),
(2, 'added to wallet', '22Feb2017', 100, '9203216593693847'),
(2, 'RECHARGE TO MOBILE', '22Feb2017', 50, '9763318122'),
(2, 'paytm to paytm transfer', '22Feb2017', 20, 'userid:1'),
(2, 'paytm to paytm transfer', '22Feb2017', 100, 'userid:1'),
(2, 'paytm to paytm transfer', '22Feb2017', 100, 'userid:1'),
(2, 'added to wallet', '22Feb2017', 1000, '9203216593693847'),
(2, 'paytm to paytm transfer', '22Feb2017', 200, 'userid:1'),
(2, 'paytm to paytm transfer', '22Feb2017', 50, 'userid:1'),
(1, 'Received from Paytm', '22Feb2017', 50, 'pavanyewale@gmail.com'),
(2, 'bank transfer', '23Feb2017', 200, '4'),
(2, 'RECHARGE TO MOBILE', '26Feb2017', 400, '9585394573'),
(2, 'added to wallet', '26Feb2017', 20, '9203216593693847');

-- --------------------------------------------------------

--
-- Table structure for table `paytm`
--

CREATE TABLE `paytm` (
  `userid` int(11) NOT NULL auto_increment,
  `name` varchar(30) default NULL,
  `email` varchar(50) default NULL,
  `password` varchar(8) NOT NULL,
  `gender` varchar(8) default NULL,
  `mobileno` int(10) NOT NULL,
  `amount` decimal(8,2) unsigned zerofill default NULL,
  `photopath` varchar(20) default NULL,
  PRIMARY KEY  (`userid`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `paytm`
--

INSERT INTO `paytm` (`userid`, `name`, `email`, `password`, `gender`, `mobileno`, `amount`, `photopath`) VALUES
(1, 'pavan YEWALE', 'pavanyewale497@gmail.com', 'PAVAN', 'male', 2147483647, '001970.00', NULL),
(2, 'rohit korhale', 'pavanyewale@gmail.com', '49749749', 'male', 2147483647, '000170.00', NULL),
(3, 'pavn YEWALE', 'pavan@gmail.com', 'pavan', 'male', 2147483647, '000000.00', NULL),
(4, 'Rahul  Pawar', 'rp@gmail.com', '49749749', 'male', 2147483647, '000000.00', NULL),
(7, 'tfhdf fgf', 'pavanyewale123@gmail.com', '12345', 'male', 1234567890, '000000.00', NULL),
(9, 'dvvxf bfgbfgbfg', 'f@gmail.com', '12345', 'female', 1234567888, '000000.00', NULL),
(10, 'hello jhghjgf', 'a@g.com', 'pavan', 'male', 1234456768, '000000.00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sell`
--

CREATE TABLE `sell` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `price` int(11) default NULL,
  `photopath` varchar(40) default NULL,
  `discount` int(11) default NULL,
  `description` text,
  `contity` int(11) default NULL,
  `category` varchar(50) default NULL,
  `seller_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=70 ;

--
-- Dumping data for table `sell`
--

INSERT INTO `sell` (`id`, `name`, `price`, `photopath`, `discount`, `description`, `contity`, `category`, `seller_id`) VALUES
(58, 'school bag', 450, 'BAZZAR/', 0, 'JLKSJFAJFASLKJFJ', 50, 'BAZZAR', 0),
(59, 'reyban gogle', 199, 'MENS FASHION/', 20, 'this is a very lice looking gogle at very cheap rate\r\n', 10, 'MENS FASHION', 0),
(64, 'baby toy', 100, 'BABY KIDS/', 5, 'DRTHHDTYYH', 10, 'BABY KIDS', 0),
(65, 'mobile accessories', 200, 'MOBILE ACCESSORIES/', 20, ';lksdjf;kasjfk;lj', 10, 'MOBILE ACCESSORIES', 0),
(66, 'mobile an', 555, 'MOBILE ACCESSORIES/', 10, 'JHCBGKDJBN KJFN ZSKJFNZSKJF', 6, 'MOBILE ACCESSORIES', 0),
(68, 'women wear', 99, 'WOMENS FASHION/', 0, 'mhgfjhf\r\nlk\r\nryui;''\r\ngfghjkl;''\r\nlkjhgfhjkl;''\r\ntretyuiop''\r\nrtfhuyjiol;''\r\nrtuyhjkl;''\r\nghjkl;''\r\nuiokpl;[''\r\n', 5, 'WOMENS FASHION', 2),
(69, 'dfgfg', 56, 'MOBILE ACCESSORIES/', 56, 'fgjuiyfujyn', 6, 'MOBILE ACCESSORIES', 2);

-- --------------------------------------------------------

--
-- Table structure for table `userimage`
--

CREATE TABLE `userimage` (
  `userid` int(11) default NULL,
  `up_date` date default NULL,
  `img` longblob,
  `iname` varchar(20) default NULL,
  `likes` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userimage`
--

