-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 09, 2017 at 10:31 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `paytm`
--
drop database if exists paytm;
create database paytm;
use paytm;
-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(8) NOT NULL,
  `gender` varchar(8) default NULL,
  `accountno` int(11) NOT NULL auto_increment,
  `amount` int(11) default NULL,
  `cvvno` int(3) default NULL,
  `exmonth` int(2) default NULL,
  `ex_year` int(4) default NULL,
  `atmno` bigint(16) default NULL,
  `atmpassword` int(4) NOT NULL,
  PRIMARY KEY  (`accountno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`fname`, `lname`, `email`, `password`, `gender`, `accountno`, `amount`, `cvvno`, `exmonth`, `ex_year`, `atmno`, `atmpassword`) VALUES
('PAYTM', 'PT', 'paytm@gmail.com', '49749749', 'male', 1, 1219, 111, 2, 2037, 98457984734598734, 4974),
('rohit', 'korhale', 'rk@gmail.com', '12345678', 'male', 4, 6030, 499, 2, 2037, 9203216593693847, 6528);

-- --------------------------------------------------------

--
-- Table structure for table `passbook`
--

CREATE TABLE `passbook` (
  `userid` int(11) default NULL,
  `ttype` text,
  `tdate` varchar(20) default NULL,
  `tamount` float default '0',
  `tfor` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `passbook`
--

INSERT INTO `passbook` (`userid`, `ttype`, `tdate`, `tamount`, `tfor`) VALUES
(1, 'Received from Paytm', '22Feb2017', 50, 'pavanyewale@gmail.com'),
(12, 'added to wallet', '08Mar2017', 100, '9203216593693847'),
(12, 'added to wallet', '08Mar2017', 50, '9203216593693847'),
(2, 'added to wallet', '08Mar2017', 1000, '9203216593693847'),
(2, 'added to wallet', '08Mar2017', 1000, '9203216593693847'),
(2, 'accepted for shopping', '09/03/17', 100, 'yewale pavan'),
(2, 'accepted for shopping', '09/03/17', 100, 'yewale pavan'),
(2, 'accepted for shopping', '09/03/17', 100, 'yewale pavan'),
(0, 'accepted for shopping', '09/03/17', 100, 'PAVN'),
(0, 'accepted for shopping', '09/03/17', 100, 'PAVN'),
(0, 'accepted for shopping', '09/03/17', 100, 'PAVN'),
(2, 'RECHARGE TO MOBILE', '09Mar2017', 50, '9864873646'),
(2, 'added to wallet', '09Mar2017', 50, '9203216593693847'),
(2, 'bank transfer', '09Mar2017', 100, '1'),
(2, 'bank transfer', '09Mar2017', 1000, '1'),
(2, 'accepted for shopping', '09/03/17', 455, 'pavan yewale'),
(0, 'accepted for selling product', '09/03/17', 100, 'pavanyewale'),
(2, 'accepted for selling product', '09/03/17', 455, 'pavan yewale'),
(2, 'accepted for selling product', '09/03/17', 455, 'pavan yewale'),
(0, 'accepted for selling product', '09/03/17', 199, 'pavanyewale'),
(0, 'accepted for selling product', '09/03/17', 100, 'akshay wakale'),
(0, 'accepted for selling product', '09/03/17', 199, 'kojff'),
(0, 'accepted for selling product', '09/03/17', 100, 'vidkof');

-- --------------------------------------------------------

--
-- Table structure for table `paytm`
--

CREATE TABLE `paytm` (
  `userid` int(11) NOT NULL auto_increment,
  `name` varchar(30) default NULL,
  `email` varchar(50) default NULL,
  `password` varchar(8) NOT NULL,
  `gender` varchar(8) default NULL,
  `mobileno` int(10) NOT NULL,
  `amount` decimal(8,2) unsigned zerofill default NULL,
  PRIMARY KEY  (`userid`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `paytm`
--

INSERT INTO `paytm` (`userid`, `name`, `email`, `password`, `gender`, `mobileno`, `amount`) VALUES
(1, 'pavan YEWALE', 'pavanyewale497@gmail.com', 'PAVAN', 'male', 2147483647, '001770.00'),
(2, 'rohit korhale', 'pavanyewale@gmail.com', '49749749', 'male', 2147483647, '000008.00'),
(3, 'pavn YEWALE', 'pavan@gmail.com', 'pavan', 'male', 2147483647, '000000.00'),
(4, 'Rahul  Pawar', 'rp@gmail.com', '49749749', 'male', 2147483647, '000000.00'),
(7, 'tfhdf fgf', 'pavanyewale123@gmail.com', '12345', 'male', 1234567890, '000000.00'),
(9, 'dvvxf bfgbfgbfg', 'f@gmail.com', '12345', 'female', 1234567888, '000000.00'),
(10, 'hello jhghjgf', 'a@g.com', 'pavan', 'male', 1234456768, '000000.00'),
(11, 'rahul yewale', 'ryewale@gmail.com', '49749749', 'male', 2147483647, '000000.00'),
(12, 'prasad rohokale', 'prohokale@gmail.com', '49749749', 'male', 2147483647, '000000.00');

-- --------------------------------------------------------

--
-- Table structure for table `sell`
--

CREATE TABLE `sell` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `price` int(11) default NULL,
  `photopath` varchar(40) default NULL,
  `discount` int(11) default NULL,
  `description` text,
  `contity` int(11) default NULL,
  `category` varchar(50) default NULL,
  `seller_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=79 ;

--
-- Dumping data for table `sell`
--

INSERT INTO `sell` (`id`, `name`, `price`, `photopath`, `discount`, `description`, `contity`, `category`, `seller_id`) VALUES
(58, 'school bag', 450, 'BAZZAR/', 0, 'JLKSJFAJFASLKJFJ', 50, 'BAZZAR', 0),
(59, 'reyban gogle', 199, 'MENS FASHION/', 20, 'this is a very lice looking gogle at very cheap rate\r\n', 10, 'MENS FASHION', 0),
(64, 'baby toy', 100, 'BABY KIDS/', 5, 'DRTHHDTYYH', 10, 'BABY KIDS', 0),
(65, 'mobile accessories', 200, 'MOBILE ACCESSORIES/', 20, ';lksdjf;kasjfk;lj', 10, 'MOBILE ACCESSORIES', 0),
(78, 'google', 455, 'MENS FASHION/', 40, 'ldkfjalkjfl;aj;f adfa dlfjdfjlsdjfa dfjadjf', 45, 'MENS FASHION', 2);

-- --------------------------------------------------------

--
-- Table structure for table `shipping_details`
--

CREATE TABLE `shipping_details` (
  `seller_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `mobile` int(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `name` varchar(20) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shipping_details`
--

INSERT INTO `shipping_details` (`seller_id`, `product_id`, `mobile`, `address`, `name`, `uid`) VALUES
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'ap daithane gunjal tal parner dist ahmednagar', 'yewale pavan', 0),
(0, 64, 2147483647, 'KLJVLZCJVLCJVL;ZJVLZ', 'PAVN', 0),
(0, 64, 2147483647, 'KLJVLZCJVLCJVL;ZJVLZ', 'PAVN', 0),
(2, 78, 2147483647, 'ap daithane gunjal tal parner dist ahmednhara', 'pavan yewale', 0),
(2, 78, 2147483647, 'ap daithane gunjal tal parner dist ahmednhara', 'pavan yewale', 2),
(0, 59, 2147483647, 'kdjf kfj lfjfj efj afj fj a;lfj', 'pavanyewale', 2),
(0, 64, 2147483647, 'laskjdflajfl afasdlfjasdfja;ldf \r\n', 'akshay wakale', 2),
(0, 59, 2147483647, 'jijiffdkdokd', 'kojff', 2),
(0, 64, 2147483647, 'okdokd', 'vidkof', 2);

-- --------------------------------------------------------

--
-- Table structure for table `userimage`
--

CREATE TABLE `userimage` (
  `userid` int(11) default NULL,
  `up_date` date default NULL,
  `img` longblob,
  `iname` varchar(20) default NULL,
  `likes` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userimage`
--

