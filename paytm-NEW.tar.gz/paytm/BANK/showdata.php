<?php
$error=null;

error_reporting(E_ALL ^ E_WARNING);
 $conn= mysqli_connect("localhost",'root','') or die("cannot connect to localhost");
mysqli_select_db($conn,"paytm") or die("cannot select database");


?>
<!doctype html>
<html>
<head>
<link rel="stylesheet" href="createacc.css" type="text/css"> 
<meta charset="utf-8">
<title>Money Deposite</title>
</head>

<body bgcolor="#D2D5CD">
<div id="container" class="container">


<div id="head" class="hdr"><strong>All Bank Data</strong></div>





<div class="form">
  <center>
  <a href="depositemoney.php?deposite=0" style="font-color="white""
   >
  <div class="option">
   Deposite a Money</div></a>
  </center>


  <center> <a href="bankaccount.php" style="font-color="white""
   >
    <div class="option">Create Bank Account</div></a>
  </center>

</div>

<?php
$sql='select * from bank where accountno='.$_GET["accountno"];
$result=mysqli_query($conn,$sql);
/*foreach($result as mysqli_fetch_array($result))
{
	
	}*/

?>
</center>
</body>
</html>