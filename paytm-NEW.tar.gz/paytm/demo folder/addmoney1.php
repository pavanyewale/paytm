<!doctype html>
<html>
<head>
<link rel="stylesheet" href="createacc.css" type="text/css">

<meta charset="utf-8">
<title>Add Money</title>
</head>

<body>
<div class="container">
<div class="form">
<form method="post" action="addmoney.php">
<input type="number" class="input" name="atmno" maxlength="16" value="<?php setvalue("atmno"); ?>">
<input type="number" class="input" name="password" value="<?php setvalue("password"); ?>">
<input type="number" class="input" maxlength="3" name="cvvno" value="<?php setvalue("cvvno"); ?>">
<input type="number" class="date" maxlength="2" name="month" value="<?php setvalue("month"); ?>">
<input type="number" class="date" maxlength="4" name="year" value="<?php setvalue("year"); ?>">
<input type="submit" class="Button" name="submit" value="ADD to Wallet">

hello



</form>
</div>
</div>


</body>
</html>