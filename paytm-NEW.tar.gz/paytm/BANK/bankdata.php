<?php

error_reporting(E_ALL ^ E_WARNING);
$error=null;
 $conn= mysqli_connect("localhost",'root','') or die("cannot connect to localhost");
mysqli_select_db($conn,"paytm") or die("cannot select database");



/////delete bank account
if(isset($_GET['delete']))
		{
			$sql='delete from bank where accountno='.$_GET['delete'];
			mysqli_query($conn,$sql) or die('cannot delete account'.mysqli_error($conn));}
?>
<!doctype html>
<html>
<head>
<link rel="stylesheet" href="createacc.css" type="text/css"> 
<meta charset="utf-8">
<title>paytm</title>
</head>

<body bgcolor="#D2D5CD">
<div id="container" class="container">

<div id="head" class="hdr"><strong>All Bank Data</strong></div>


<div class="form">
  <center>
  <a href="depositemoney.php?deposite=0" style="font-color="white""
   >
  <div class="option">
   Deposite a Money</div></a>
  </center>


  <center> <a href="bankaccount.php" style="font-color="white""
   >
    <div class="option">Create bank Account</div></a>
  </center>

</div>
<table id="t1" cellpadding="4px" cellspacing="4px">
<th>Sr.no.</th><th>Acc. No.</th><th>Name</th><th>Amount</th><th>ATM No</th><th>ATM Pass.</th><th>ATM expriry</th><th>ATM CVV</th><th>OPTION</th>

  <?php 
$sql='select * from bank';
$data=mysqli_query($conn,$sql);
$n=0;
while($row=mysqli_fetch_row($data))
{
	echo ' <tr>
	<td>';
echo ++$n.'</td>';//sr.no

echo '<td>'.$row[5].'</td>';//acc no
echo '<td>'.$row[0].'&nbsp'.$row[1].'</td>';//name
echo '<td>'.$row[6].'</td>';//ammount
echo '<td>'.$row[10].'</td>';//atm no
echo '<td>'.$row[11].'</td>';//password
echo '<td>'.$row[8].'/'.$row[9].'</td>';//atm expriry
echo '<td>'.$row[7].'</td>';//cvv no
echo '<td><a href="bankdata.php?delete='.$row[5].'">Delete</a></td>';//option

}
echo '<tr><td>Total:'.$n.'<td></tr>';
?>
  </table>
  </center>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>