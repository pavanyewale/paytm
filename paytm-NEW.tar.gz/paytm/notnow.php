<?php

	$error=null;
include'welcome.php';

?><!doctype html>
<html>
<head>
<link rel="stylesheet" href="form.css" type="text/css"> 

<style>
.notnow{
	float:left;
	font-size:25px;
	color:#AC00AB;
	width:1350px;
		
	}
</style>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body bgcolor="#D2D5CD"><br><br><br>
<div class='notnow'><center>
This service <br>Currently Not Available<br>
<strong><marquee direction="right"><font color="#FF5700">comming soon</font></marquee></strong></div>

</center>
</body>
</html>
<?php
include'footer.php';
?>
