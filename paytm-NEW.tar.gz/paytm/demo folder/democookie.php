
<?php 
if(isset($_COOKIE['password']))
{
	echo $_COOKIE['id'];
	 echo $_COOKIE['password'];
	
	}
?>