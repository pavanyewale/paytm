<?php

error_reporting(E_ALL ^ E_WARNING);
$error=null;
 $conn= mysqli_connect("localhost",'root','') or die("cannot connect to localhost");
mysqli_select_db($conn,"paytm") or die("cannot select database");


   


// ****************************************   function to set value which are set by user in previous form**********************************  
	function setValue($field)
	{
		if(isset($_POST[$field]))
		{echo $_POST[$field];
			}
		}
		
      
		
		
			
			
?>


<!doctype html>
<html>
<head>
<link rel="stylesheet" href="createacc.css" type="text/css"> 
<meta charset="utf-8">
<title>Bank Account</title>
</head>

<body bgcolor="#D2D5CD">
<div id="container" class="container">

<div id="head" class="hdr"><strong>create account in bank </strong>   </div>
<center>
  <p>This is a temporarry page to create a demo account of the bank<br>Your account will be created only by the bank employee themself..!
</center>






<?php
if(isset($_POST["create_bank_account"]))
{$i=1;


foreach($_POST as $key => $values)
{
	if($values=="")
	{$i=0;
		}
	}
	if($i==1)
	
	{if($_POST["cpassword"]==$_POST["confirm_password"])
	{
		$row=mysqli_query($conn,"select email from bank where email='".$_POST[email]."'");
		$k=1;
		if(mysqli_fetch_array($row))
		{$k=0;}
		if($k)
	{  $atmno1=rand(10000000,99999999);
	$atmno2=rand(10000000,99999999);
	$atmno=$atmno1.$atmno2;
		$atmPass=rand(1000,9999);
		$ex_month=date("m");
		$ex_year=date("Y")+20;
	$cvv=rand(100,999);
	$sql='select max(atmno) from bank';
	$result=mysqli_query($conn,$sql);
	$data=mysqli_fetch_array($result);
	foreach($data as $d)
	{
		}
		$sql="insert into bank (fname,lname,email,password,gender,amount,exmonth,ex_year,cvvno,atmno,atmpassword) values('".$_POST["fname"]."','".$_POST["lname"]."','".$_POST["email"]."','".$_POST["cpassword"]."','".$_POST["gender"]."','".$_POST["amount"]."','".$ex_month."','".$ex_year."','".$cvv."','".$atmno."','".$atmPass."') ";
	$ok= mysqli_query($conn,$sql) or die("cannot insert data &nbsp;&nbsp;&nbsp; ".mysqli_error($conn));
	if($ok)
	{
	echo'<br>';
	echo'Account created succesfully';
	}
		
		}
	
	else{
		$error=2;
		//echo'<blink>Allready have an account for this email</blink>,<br>please check the email or log in with this email,<br> if you forgot password for this email account please click on "forgot password" link and change your password';
		}}
		else{
			$error=3;
			//echo"Password don't match,please check the password and confirm password field should be same";
			}
	}
		else{
			$error=1;
			//echo"something missed to enter";
			}


}
?>

<?php if($error)
{ echo'<div id="error" class="error">';

if($error==1)
{echo"Something missed to enter";}
if($error==2)
{echo"Allready have an account for this email...!  ";
	}
	if($error==3){
		echo"password and confirm password should be same...!";
		}
	
echo'</div>';
	}
	
?>

<div class="form">
  <center>
  <a href="depositemoney.php?deposite=0" style="font-color="white""
   >
  <div class="option">
   Deposite a Money</div></a>
  </center>


  <center> <a href="bankdata.php" style="font-color="white""
   >
    <div class="option">
   Show All Data</div></a>
  </center>

</div>
<div id="form" class="form">

<form method="post" action="bankaccount.php">
 <div class="lbl"><label><strong>Name</strong></label></div>
 <div id="fname"><input name="fname" type="text" placeholder="first" size="10" maxlength="10" value="<?php setvalue("fname"); ?>" class="input"></div>
 <input name="lname" class="input" type="text" placeholder="last" size="10" maxlength="10" value="<?php setvalue("lname"); ?>">
 <div class="lbl"> <label><strong>Gender</strong></label></div><div id="gender"><input type="radio" name="gender" value="male" <?php if(isset($_POST['signup']))
  {
if(isset($_POST["gender"]) && $_POST["gender"]=="male"){
	echo'checked="1"';}}?>> Male<input type="radio" name="gender" value="female"  <?php if(isset($_POST['signup']))
  {
if(isset($_POST["gender"]) and $_POST["gender"]=="female"){
	echo'checked="1"';}}?>>Female
    </div>
 <div class="lbl"> <label><strong>Email</strong></label></div><input name="email"  class="input" type="email" placeholder="email addresss" value="<?php setvalue("email"); ?>">
  <div class="lbl"><label><strong>New Password</strong></label></div>
  <input name="cpassword"  class="input" type="password" placeholder="password" maxlength="8"value="<?php setvalue("cpassword"); ?>"><br>
 <div class="lbl"> <label>
    <strong>
      Confirm Password
    </strong></label></div><input name="confirm_password" class="input" type="password" maxlength="8"placeholder="confirm-password" value="<?php setvalue("confirm_password"); ?>" >
    
    <div class="lbl"><strong>first Demosit Amount</strong></div>
    <div class="lbl"></div>
    
    
    <input name="amount" class="input" type="number" placeholder="Enter Amount" value="<?php setvalue("amount"); ?>" >
    <input class="Button" type="submit" name="create_bank_account" value="create account" >
</form>
</div>




</div>
<br>
</body>
</html>
