<?php

error_reporting(E_ALL ^ E_WARNING);
$error=null;
 $conn= mysqli_connect("localhost",'root','') or die("cannot connect to localhost");
mysqli_select_db($conn,"paytm") or die("cannot select database");


   


// ****************************************   function to set value which are set by user in previous form**********************************  
	function setValue($field)
	{
		if(isset($_POST[$field]))
		{echo $_POST[$field];
			}
		}
		
        
?>


<!doctype html>
<html>
<head>
<link rel="stylesheet" href="createacc.css" type="text/css"> 
<meta charset="utf-8">
<title>Money Deposite</title>
</head>

<body bgcolor="#D2D5CD">
<div id="container" class="container">

<div id="head" class="hdr"><strong>Deposite Money to Account</strong></div>
<center>
  <p>This is a temporarry page to Deposite a money to account of the bank<br>
    Your account will be deposited only by the bank employee or money transfer machine !
</center>


<div class="form">
  <center>
  <a href="bankaccount.php" style="font-color="white""
   >
  <div class="option">Create Bank Account</div></a>
  </center>


  <center> <a href="bankdata.php" style="font-color="white""
   >
    <div class="option">
   Show All Data</div></a>
  </center>

</div>

<?php 
if($_GET["deposite"]==1)
{?>

<div id="depositesuccessfull" class="cna">account is credited successfully</div>

<?php
}
?>




<?php
if(isset($_POST["deposite"]))
{$i=1;
foreach($_POST as $key => $values)
{
	if($values=="")
	{$i=0;
		}
}
if($i==1)
{
  $row = mysqli_query($conn,"select accountno from bank where accountno='".$_POST['accountno']."'");
  $k=0;
	if(mysqli_fetch_array($row))
	{$k=1;}
	     if($k)
	     {
	       $sql='update  bank set amount=amount+'.$_POST["amount"].'  where accountno='.$_POST["accountno"].'';	
		   echo $sql;
	       $ok= mysqli_query($conn,$sql) or die("cannot insert data &nbsp;&nbsp;&nbsp; ".mysqli_error($conn));
	          if($ok)
	           {
	            echo'<br>';
	            echo'account is updated';
				header("location:depositemoney.php?deposite=0?deposite=1");
	            }
		
		  }else{
			  
			  $error=2;
			  }
}
else{
	$error=1;
	}
}
?>

<?php if($error)
{ echo'<div id="error" class="error">';

if($error==1)
{echo"Something missed to enter";}
if($error==2)
{
	echo'Account no is Invalid';
	}	
echo'</div>';
	}
	
?>
<div id="form" class="form">

<form method="post" action="depositemoney.php?deposite=0">
 <div class="lbl"><strong> Account No</strong></div>
 <div id="fname"><input name="accountno" type="text" placeholder="Account No" size="10" maxlength="10" value="<?php setvalue("accountno"); ?>" class="input"></div><br>
 <div class="lbl"><strong> Demosit Amount</strong></div>
    
    
    
    <input name="amount" class="input" type="number" placeholder="Enter Amount" value="<?php setvalue("amount"); ?>" >
    
<input class="Button" type="submit" name="deposite" value="Deposite" >
</form></div>
<div class="form">
 
</div>
<br>
</body>
</html>
