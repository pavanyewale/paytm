<?php

header('location:start.php');
?>
