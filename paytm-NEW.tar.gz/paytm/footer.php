 <html><body><footer style="background-color:#A29596; width:100%; clear:both;">
<br>
    <center>
    <pre>
<a href="help.php">help center </a>   |     <a href="aboutus.html">about us</a>   |  <a href="feedback.html">feedback</a><br><br><a href="termsnconditions.html">terms&conditions </a>
   <address>copyrights:2018-<?php echo date(y);?>
      <br>All rights reserved to Mugdha & Harshanjali
</address> 
   </center>
</footer>
</body>
</html>
